require('dotenv').config();
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
const Keycloak = require('keycloak-connect');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Session store required by keycloak-connect
const memoryStore = new session.MemoryStore();
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-me-in-env',
  resave: false,
  saveUninitialized: true,
  store: memoryStore
}));

const keycloak = new Keycloak({ store: memoryStore }, require('./keycloak-config.json'));
app.use(keycloak.middleware());

// Middleware: require a valid Keycloak token and extract the user's email
// onto req.userEmail so route handlers never trust client-supplied identity.
function requireAuth(req, res, next) {
  // GET requests are public and won't carry a grant - skip through
  if (req.method === 'GET') return next();

  const grant = req.kauth && req.kauth.grant;
  if (!grant) return res.status(401).json({ error: 'Not authenticated' });
  const email = grant.access_token.content.email;
  if (!email) return res.status(401).json({ error: 'Token missing email claim' });
  req.userEmail = email;
  next();
}

// Public: resource (room) list, read-only
app.use('/api/resources', require('./routes/resources'));

// Bookings: GET is public, POST/DELETE enforce Keycloak auth inside the router
app.use('/api/bookings', keycloak.protect((token, req) => {
  // Only require login for write operations; allow anonymous GET
  return req.method !== 'GET';
}), requireAuth, require('./routes/bookings'));

// Expose current logged-in user's email to the frontend
app.get('/api/me', keycloak.protect(), requireAuth, (req, res) => {
  res.json({ email: req.userEmail });
});

app.listen(PORT, () => {
  console.log(`Booking app listening on port ${PORT}`);
});
