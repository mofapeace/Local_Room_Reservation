const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/resources - list all bookable rooms
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, name, capacity, location FROM rooms ORDER BY name');
    res.json(rows);
  } catch (err) {
    console.error('Failed to fetch rooms:', err.message);
    res.status(500).json({ error: 'Could not fetch rooms' });
  }
});

module.exports = router;
