const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/bookings?date=YYYY-MM-DD - all bookings for a given day (all rooms)
router.get('/', async (req, res) => {
  const { date } = req.query;
  try {
    let sql = `SELECT id, room_id, user_email, title, start_time, end_time FROM bookings`;
    const params = [];
    if (date) {
      sql += ` WHERE DATE(start_time) = ?`;
      params.push(date);
    }
    sql += ` ORDER BY start_time`;
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('Failed to fetch bookings:', err.message);
    res.status(500).json({ error: 'Could not fetch bookings' });
  }
});

// POST /api/bookings - create a booking
// user_email is NEVER taken from the request body; it's read from the
// Keycloak-authenticated token on req.kauth, set by the auth middleware in server.js
router.post('/', async (req, res) => {
  const { room_id, title, start_time, end_time } = req.body;
  const userEmail = req.userEmail; // injected by requireAuth middleware

  if (!room_id || !title || !start_time || !end_time) {
    return res.status(400).json({ error: 'room_id, title, start_time, end_time are required' });
  }

  try {
    // Prevent overlapping bookings for the same room
    const [conflicts] = await pool.query(
      `SELECT id FROM bookings
       WHERE room_id = ?
         AND NOT (end_time <= ? OR start_time >= ?)`,
      [room_id, start_time, end_time]
    );
    if (conflicts.length > 0) {
      return res.status(409).json({ error: 'This slot overlaps an existing booking' });
    }

    const [result] = await pool.query(
      `INSERT INTO bookings (room_id, user_email, title, start_time, end_time)
       VALUES (?, ?, ?, ?, ?)`,
      [room_id, userEmail, title, start_time, end_time]
    );
    res.status(201).json({ id: result.insertId, room_id, user_email: userEmail, title, start_time, end_time });
  } catch (err) {
    console.error('Failed to create booking:', err.message);
    res.status(500).json({ error: 'Could not create booking' });
  }
});

// DELETE /api/bookings/:id - only the booking's owner can cancel it
router.delete('/:id', async (req, res) => {
  const userEmail = req.userEmail;
  try {
    const [rows] = await pool.query('SELECT user_email FROM bookings WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Booking not found' });
    if (rows[0].user_email !== userEmail) {
      return res.status(403).json({ error: 'You can only cancel your own bookings' });
    }
    await pool.query('DELETE FROM bookings WHERE id = ?', [req.params.id]);
    res.status(204).send();
  } catch (err) {
    console.error('Failed to delete booking:', err.message);
    res.status(500).json({ error: 'Could not delete booking' });
  }
});

module.exports = router;
