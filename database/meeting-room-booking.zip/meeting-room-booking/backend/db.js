const mysql = require('mysql2/promise');

// Connection details come entirely from environment variables.
// DevOps injects these via the root .env / docker-compose.yml
// (DB_HOST=db, matching the MySQL service name on the Docker bridge network).
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'booking_system',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool;
