-- Meeting Room & Resource Booking System schema

CREATE DATABASE IF NOT EXISTS booking_system;
USE booking_system;

CREATE TABLE IF NOT EXISTS rooms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  capacity INT DEFAULT 4,
  location VARCHAR(100) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT NOT NULL,
  user_email VARCHAR(255) NOT NULL,        -- tagged from Keycloak token, never client-supplied
  title VARCHAR(200) NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
  CONSTRAINT chk_time_order CHECK (end_time > start_time)
);

-- Seed a few sample rooms
INSERT INTO rooms (name, capacity, location) VALUES
  ('Conference Room A', 10, 'Floor 1'),
  ('Conference Room B', 6, 'Floor 1'),
  ('Huddle Room 1', 4, 'Floor 2'),
  ('Huddle Room 2', 4, 'Floor 2');
