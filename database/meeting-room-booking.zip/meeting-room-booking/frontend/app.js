// ---- Config ----------------------------------------------------------
const SLOT_START_HOUR = 8;   // 08:00
const SLOT_END_HOUR = 18;    // 18:00
const SLOT_MINUTES = 60;     // 1-hour slots

const keycloakConfig = {
  url: 'http://localhost:8080/', // Keycloak base URL - matches DevOps' docker-compose service
  realm: 'booking-realm',
  clientId: 'booking-app'
};

let keycloak = null;
let currentUserEmail = null;
let rooms = [];
let bookings = [];
let selectedDate = new Date();
let filterRoomId = 'all'; // 'all' or a room id, from the resource filter dropdown

// ---- Auth (Keycloak OIDC) ---------------------------------------------
async function initAuth() {
  keycloak = new Keycloak(keycloakConfig);
  try {
    const authenticated = await keycloak.init({ onLoad: 'check-sso', silentCheckSsoRedirectUri: window.location.origin + '/silent-check-sso.html' });
    if (authenticated) {
      currentUserEmail = keycloak.tokenParsed.email;
      renderAuthState();
    }
  } catch (err) {
    console.error('Keycloak init failed', err);
  }
}

function renderAuthState() {
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  const emailEl = document.getElementById('userEmail');

  if (currentUserEmail) {
    emailEl.textContent = currentUserEmail;
    loginBtn.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
  } else {
    emailEl.textContent = '';
    loginBtn.classList.remove('hidden');
    logoutBtn.classList.add('hidden');
  }
}

document.getElementById('resourceFilter').addEventListener('change', e => {
  filterRoomId = e.target.value;
  renderGrid();
});

document.getElementById('loginBtn').addEventListener('click', () => keycloak.login());
document.getElementById('logoutBtn').addEventListener('click', () => keycloak.logout({ redirectUri: window.location.origin }));

// Attach bearer token to any authenticated API call
async function authedFetch(url, options = {}) {
  if (keycloak && keycloak.authenticated) {
    try { await keycloak.updateToken(30); } catch (e) { keycloak.login(); return; }
    options.headers = { ...(options.headers || {}), Authorization: `Bearer ${keycloak.token}` };
  }
  return fetch(url, options);
}

// ---- Data loading ------------------------------------------------------
function dateStr(d) {
  return d.toISOString().slice(0, 10);
}

async function loadRooms() {
  const res = await fetch('/api/resources');
  rooms = await res.json();
  populateResourceFilter();
}

function populateResourceFilter() {
  const select = document.getElementById('resourceFilter');
  const currentValue = select.value || 'all';
  select.innerHTML = '<option value="all">All rooms</option>';
  rooms.forEach(room => {
    const opt = document.createElement('option');
    opt.value = room.id;
    opt.textContent = room.name;
    select.appendChild(opt);
  });
  // preserve selection across refreshes if it still exists
  select.value = [...select.options].some(o => o.value === currentValue) ? currentValue : 'all';
}

function visibleRooms() {
  if (filterRoomId === 'all') return rooms;
  return rooms.filter(r => String(r.id) === String(filterRoomId));
}

async function loadBookings() {
  const res = await fetch(`/api/bookings?date=${dateStr(selectedDate)}`);
  bookings = await res.json();
}

async function refresh() {
  await Promise.all([loadRooms(), loadBookings()]);
  renderGrid();
}

// ---- Calendar grid rendering --------------------------------------------
function slotTimes() {
  const slots = [];
  for (let h = SLOT_START_HOUR; h < SLOT_END_HOUR; h++) {
    slots.push(h);
  }
  return slots;
}

function findBooking(roomId, hour) {
  const slotStart = new Date(selectedDate);
  slotStart.setHours(hour, 0, 0, 0);
  const slotEnd = new Date(slotStart);
  slotEnd.setHours(hour + 1, 0, 0, 0);

  return bookings.find(b => {
    if (b.room_id !== roomId) return false;
    const bStart = new Date(b.start_time);
    const bEnd = new Date(b.end_time);
    return bStart < slotEnd && bEnd > slotStart;
  });
}

function renderGrid() {
  const grid = document.getElementById('calendarGrid');
  grid.innerHTML = '';

  const activeRooms = visibleRooms();

  if (rooms.length === 0) {
    grid.innerHTML = '<div class="empty-state">No rooms configured yet.</div>';
    return;
  }
  if (activeRooms.length === 0) {
    grid.innerHTML = '<div class="empty-state">No rooms match the current filter.</div>';
    return;
  }

  grid.style.gridTemplateColumns = `90px repeat(${activeRooms.length}, 1fr)`;

  // Header row
  const headerTime = document.createElement('div');
  headerTime.className = 'cell';
  headerTime.textContent = 'Time';
  grid.appendChild(headerTime);

  activeRooms.forEach(room => {
    const h = document.createElement('div');
    h.className = 'cell';
    h.textContent = room.name;
    grid.appendChild(h);
  });

  // Body rows
  slotTimes().forEach(hour => {
    const timeCell = document.createElement('div');
    timeCell.className = 'time-col';
    timeCell.textContent = `${String(hour).padStart(2, '0')}:00`;
    grid.appendChild(timeCell);

    activeRooms.forEach(room => {
      const cell = document.createElement('div');
      cell.className = 'slot';

      const booking = findBooking(room.id, hour);
      if (booking) {
        const isMine = currentUserEmail && booking.user_email === currentUserEmail;
        cell.classList.add(isMine ? 'mine' : 'booked');
        cell.innerHTML = `<div class="booking-chip">${escapeHtml(booking.title)}<span class="who">${escapeHtml(booking.user_email)}</span></div>`;
        if (isMine) {
          cell.title = 'Click to cancel your booking';
          cell.addEventListener('click', () => cancelBooking(booking.id));
        }
      } else {
        cell.addEventListener('click', () => openBookingModal(room, hour));
      }

      grid.appendChild(cell);
    });
  });

  maybeDrawNowLine();
}

function maybeDrawNowLine() {
  const now = new Date();
  if (dateStr(now) !== dateStr(selectedDate)) return;
  if (now.getHours() < SLOT_START_HOUR || now.getHours() >= SLOT_END_HOUR) return;
  // Visual nicety only; grid is simple enough that a precise overlay isn't essential here.
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---- Booking modal -------------------------------------------------------
let pendingRoom = null;
let pendingHour = null;

function populateTimeSlotSelect(selectedHour) {
  const select = document.getElementById('modalTimeSlot');
  select.innerHTML = '';
  slotTimes().forEach(hour => {
    const opt = document.createElement('option');
    opt.value = hour;
    opt.textContent = `${String(hour).padStart(2, '0')}:00–${String(hour + 1).padStart(2, '0')}:00`;
    if (hour === selectedHour) opt.selected = true;
    select.appendChild(opt);
  });
}

function openBookingModal(room, hour) {
  if (!keycloak || !keycloak.authenticated) {
    keycloak.login();
    return;
  }
  pendingRoom = room;
  pendingHour = hour;
  document.getElementById('modalSub').textContent = room.name;
  document.getElementById('titleInput').value = '';
  document.getElementById('modalDate').value = dateStr(selectedDate);
  populateTimeSlotSelect(hour);
  document.getElementById('modalError').textContent = '';
  document.getElementById('modalBackdrop').classList.remove('hidden');
  document.getElementById('titleInput').focus();
}

function closeModal() {
  document.getElementById('modalBackdrop').classList.add('hidden');
  pendingRoom = null;
  pendingHour = null;
}

document.getElementById('cancelModal').addEventListener('click', closeModal);

document.getElementById('confirmModal').addEventListener('click', async () => {
  const title = document.getElementById('titleInput').value.trim();
  const errorEl = document.getElementById('modalError');
  if (!title) {
    errorEl.textContent = 'Please enter a meeting title.';
    return;
  }

  const modalDateVal = document.getElementById('modalDate').value;
  const chosenHour = parseInt(document.getElementById('modalTimeSlot').value, 10);

  const start = new Date(modalDateVal + 'T00:00:00');
  start.setHours(chosenHour, 0, 0, 0);
  const end = new Date(start);
  end.setHours(chosenHour + 1, 0, 0, 0);

  try {
    const res = await authedFetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        room_id: pendingRoom.id,
        title,
        start_time: start.toISOString().slice(0, 19).replace('T', ' '),
        end_time: end.toISOString().slice(0, 19).replace('T', ' ')
      })
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      errorEl.textContent = data.error || 'Could not create booking.';
      return;
    }
    closeModal();
    // If the booking was made for a different day than currently viewed, jump there
    if (modalDateVal !== dateStr(selectedDate)) {
      setDate(new Date(modalDateVal + 'T00:00:00'));
    } else {
      await refresh();
    }
  } catch (err) {
    errorEl.textContent = 'Network error — please try again.';
  }
});

async function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  const res = await authedFetch(`/api/bookings/${id}`, { method: 'DELETE' });
  if (res.ok) await refresh();
  else alert('Could not cancel booking.');
}

// ---- Date navigation -------------------------------------------------------
function setDate(d) {
  selectedDate = d;
  document.getElementById('dateInput').value = dateStr(d);
  refresh();
}

document.getElementById('dateInput').addEventListener('change', e => setDate(new Date(e.target.value + 'T00:00:00')));
document.getElementById('prevDay').addEventListener('click', () => {
  const d = new Date(selectedDate); d.setDate(d.getDate() - 1); setDate(d);
});
document.getElementById('nextDay').addEventListener('click', () => {
  const d = new Date(selectedDate); d.setDate(d.getDate() + 1); setDate(d);
});
document.getElementById('todayBtn').addEventListener('click', () => setDate(new Date()));

// ---- Boot -------------------------------------------------------------
(async function boot() {
  document.getElementById('dateInput').value = dateStr(selectedDate);
  await initAuth();
  await refresh();
})();
