// ===========================================================================
// MOCK MODE — for previewing the UI standalone, with no backend/Keycloak/DB.
// Same DOM, same CSS classes, same interactions as app.js — just fake data
// and a simulated login instead of real fetch()/Keycloak calls.
// Swap this file back out for app.js once the real stack is running.
// ===========================================================================

const SLOT_START_HOUR = 8;
const SLOT_END_HOUR = 18;

let currentUserEmail = null; // null = logged out
const MOCK_USER_EMAIL = 'you@company.com';

let rooms = [
  { id: 1, name: 'Conference Room A' },
  { id: 2, name: 'Conference Room B' },
  { id: 3, name: 'Server Lab 01' },
  { id: 4, name: 'Workstation 05' }
];

// In-memory bookings store, keyed loosely like the real API would return them.
// start_time / end_time as 'YYYY-MM-DD HH:MM:SS' strings, same shape as backend.
let bookings = [];

let selectedDate = new Date();
let filterRoomId = 'all';
let pendingRoom = null;
let pendingHour = null;

function dateStr(d) {
  return d.toISOString().slice(0, 10);
}

// Seed a couple of fake bookings on "today" so the grid has something to show
(function seedMockData() {
  const today = dateStr(new Date());
  bookings.push(
    { id: 101, room_id: 1, user_email: 'priya@company.com', title: 'Design Review', start_time: `${today} 09:00:00`, end_time: `${today} 10:00:00` },
    { id: 102, room_id: 2, user_email: MOCK_USER_EMAIL, title: 'Sprint Planning', start_time: `${today} 11:00:00`, end_time: `${today} 12:00:00` },
    { id: 103, room_id: 3, user_email: 'devops@company.com', title: 'Infra Sync', start_time: `${today} 14:00:00`, end_time: `${today} 15:00:00` }
  );
})();

// ---- Mock auth ----------------------------------------------------------
function renderAuthState() {
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  const emailEl = document.getElementById('userEmail');

  if (currentUserEmail) {
    emailEl.textContent = currentUserEmail;
    loginBtn.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
  } else {
    emailEl.textContent = '';
    loginBtn.classList.remove('hidden');
    logoutBtn.classList.add('hidden');
  }
}

document.getElementById('loginBtn').addEventListener('click', () => {
  // Simulates the Keycloak redirect/login round trip instantly
  currentUserEmail = MOCK_USER_EMAIL;
  renderAuthState();
  renderGrid();
});

document.getElementById('logoutBtn').addEventListener('click', () => {
  currentUserEmail = null;
  renderAuthState();
  renderGrid();
});

// ---- Resource filter ------------------------------------------------------
function populateResourceFilter() {
  const select = document.getElementById('resourceFilter');
  select.innerHTML = '<option value="all">All rooms</option>';
  rooms.forEach(room => {
    const opt = document.createElement('option');
    opt.value = room.id;
    opt.textContent = room.name;
    select.appendChild(opt);
  });
}

document.getElementById('resourceFilter').addEventListener('change', e => {
  filterRoomId = e.target.value;
  renderGrid();
});

function visibleRooms() {
  if (filterRoomId === 'all') return rooms;
  return rooms.filter(r => String(r.id) === String(filterRoomId));
}

// ---- Grid rendering --------------------------------------------------------
function slotTimes() {
  const slots = [];
  for (let h = SLOT_START_HOUR; h < SLOT_END_HOUR; h++) slots.push(h);
  return slots;
}

function findBooking(roomId, hour) {
  const slotStart = new Date(selectedDate);
  slotStart.setHours(hour, 0, 0, 0);
  const slotEnd = new Date(slotStart);
  slotEnd.setHours(hour + 1, 0, 0, 0);

  return bookings.find(b => {
    if (b.room_id !== roomId) return false;
    const bStart = new Date(b.start_time.replace(' ', 'T'));
    const bEnd = new Date(b.end_time.replace(' ', 'T'));
    return bStart < slotEnd && bEnd > slotStart;
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function renderGrid() {
  const grid = document.getElementById('calendarGrid');
  grid.innerHTML = '';

  const activeRooms = visibleRooms();
  if (activeRooms.length === 0) {
    grid.innerHTML = '<div class="empty-state">No rooms match the current filter.</div>';
    return;
  }

  grid.style.gridTemplateColumns = `90px repeat(${activeRooms.length}, 1fr)`;

  const headerTime = document.createElement('div');
  headerTime.className = 'cell';
  headerTime.textContent = 'Time';
  grid.appendChild(headerTime);

  activeRooms.forEach(room => {
    const h = document.createElement('div');
    h.className = 'cell';
    h.textContent = room.name;
    grid.appendChild(h);
  });

  slotTimes().forEach(hour => {
    const timeCell = document.createElement('div');
    timeCell.className = 'time-col';
    timeCell.textContent = `${String(hour).padStart(2, '0')}:00`;
    grid.appendChild(timeCell);

    activeRooms.forEach(room => {
      const cell = document.createElement('div');
      cell.className = 'slot';

      const booking = findBooking(room.id, hour);
      if (booking) {
        const isMine = currentUserEmail && booking.user_email === currentUserEmail;
        cell.classList.add(isMine ? 'mine' : 'booked');
        cell.innerHTML = `<div class="booking-chip">${escapeHtml(booking.title)}<span class="who">${escapeHtml(booking.user_email)}</span></div>`;
        if (isMine) {
          cell.title = 'Click to cancel your booking (mock)';
          cell.addEventListener('click', () => cancelBooking(booking.id));
        }
      } else {
        cell.addEventListener('click', () => openBookingModal(room, hour));
      }

      grid.appendChild(cell);
    });
  });
}

// ---- Booking modal (mock create) -------------------------------------------
function populateTimeSlotSelect(selectedHour) {
  const select = document.getElementById('modalTimeSlot');
  select.innerHTML = '';
  slotTimes().forEach(hour => {
    const opt = document.createElement('option');
    opt.value = hour;
    opt.textContent = `${String(hour).padStart(2, '0')}:00–${String(hour + 1).padStart(2, '0')}:00`;
    if (hour === selectedHour) opt.selected = true;
    select.appendChild(opt);
  });
}

function openBookingModal(room, hour) {
  if (!currentUserEmail) {
    // simulate Keycloak login prompt
    document.getElementById('loginBtn').click();
  }
  pendingRoom = room;
  pendingHour = hour;
  document.getElementById('modalSub').textContent = room.name;
  document.getElementById('titleInput').value = '';
  document.getElementById('modalDate').value = dateStr(selectedDate);
  populateTimeSlotSelect(hour);
  document.getElementById('modalError').textContent = '';
  document.getElementById('modalBackdrop').classList.remove('hidden');
  document.getElementById('titleInput').focus();
}

function closeModal() {
  document.getElementById('modalBackdrop').classList.add('hidden');
  pendingRoom = null;
  pendingHour = null;
}

document.getElementById('cancelModal').addEventListener('click', closeModal);

document.getElementById('confirmModal').addEventListener('click', () => {
  const title = document.getElementById('titleInput').value.trim();
  const errorEl = document.getElementById('modalError');
  if (!title) {
    errorEl.textContent = 'Please enter a meeting title.';
    return;
  }

  const modalDateVal = document.getElementById('modalDate').value;
  const chosenHour = parseInt(document.getElementById('modalTimeSlot').value, 10);

  const startStr = `${modalDateVal} ${String(chosenHour).padStart(2, '0')}:00:00`;
  const endStr = `${modalDateVal} ${String(chosenHour + 1).padStart(2, '0')}:00:00`;

  // Mimic the backend's overlap check (start < newEnd AND end > newStart)
  const conflict = bookings.some(b =>
    b.room_id === pendingRoom.id &&
    new Date(b.start_time.replace(' ', 'T')) < new Date(endStr.replace(' ', 'T')) &&
    new Date(b.end_time.replace(' ', 'T')) > new Date(startStr.replace(' ', 'T'))
  );
  if (conflict) {
    errorEl.textContent = 'This slot overlaps an existing booking.';
    return;
  }

  bookings.push({
    id: Date.now(),
    room_id: pendingRoom.id,
    user_email: currentUserEmail,
    title,
    start_time: startStr,
    end_time: endStr
  });

  closeModal();
  if (modalDateVal !== dateStr(selectedDate)) {
    setDate(new Date(modalDateVal + 'T00:00:00'));
  } else {
    renderGrid();
  }
});

function cancelBooking(id) {
  if (!confirm('Cancel this booking? (mock)')) return;
  bookings = bookings.filter(b => b.id !== id);
  renderGrid();
}

// ---- Date navigation -------------------------------------------------------
function setDate(d) {
  selectedDate = d;
  document.getElementById('dateInput').value = dateStr(d);
  renderGrid();
}

document.getElementById('dateInput').addEventListener('change', e => setDate(new Date(e.target.value + 'T00:00:00')));
document.getElementById('prevDay').addEventListener('click', () => {
  const d = new Date(selectedDate); d.setDate(d.getDate() - 1); setDate(d);
});
document.getElementById('nextDay').addEventListener('click', () => {
  const d = new Date(selectedDate); d.setDate(d.getDate() + 1); setDate(d);
});
document.getElementById('todayBtn').addEventListener('click', () => setDate(new Date()));

// ---- Boot -------------------------------------------------------------
(function boot() {
  document.getElementById('dateInput').value = dateStr(selectedDate);
  populateResourceFilter();
  renderAuthState();
  renderGrid();
})();
