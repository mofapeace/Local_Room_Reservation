# Meeting Room & Resource Booking System — UI (Task 4)

This covers the calendar grid UI and its Keycloak-authenticated booking flow.
Backend API + DB schema are included so the UI is runnable end-to-end, but the
canonical docker-compose/.env setup is owned by DevOps (task 5).

## What's here

```
frontend/
  index.html   - page shell, loads Keycloak JS adapter + fonts
  style.css    - calendar grid styling (ledger/office aesthetic)
  app.js       - Keycloak login, grid rendering, slot booking modal
backend/
  server.js    - Express app, Keycloak middleware, route mounting
  db.js        - MySQL pool (reads DB_HOST etc. from env — set by DevOps)
  keycloak-config.json
  routes/rooms.js
  routes/bookings.js
database/
  schema.sql   - rooms + bookings tables
```

## How bookings get tagged with the user's email

1. User clicks "Log in" → redirected through Keycloak (OIDC).
2. `app.js` holds the Keycloak access token client-side and attaches it as
   `Authorization: Bearer <token>` on every write request (`authedFetch`).
3. On the server, `keycloak.protect()` verifies the token, then `requireAuth`
   middleware (in `server.js`) pulls the `email` claim off the verified token
   and sets `req.userEmail`.
4. `routes/bookings.js` uses `req.userEmail` — **never** a client-supplied
   field — as the `user_email` column when creating a booking. This is what
   prevents someone from booking a room "as" another user.

## Grid behavior

- Columns = rooms (pulled from `GET /api/resources`), rows = hourly slots, 08:00–18:00.
- **Green** slot = available → click to open the reservation modal (prompts login first if not authenticated).
- **Red** slot = booked by someone else. **Amber** slot = your own booking, clickable to cancel.
- Resource filter dropdown narrows the grid to a single room, or "All rooms".
- Reservation modal has a title field, a date picker, and a time-slot dropdown — not locked to the cell you clicked, so you can adjust before confirming.
- Date nav (prev/next/today + date picker) reloads that day's bookings via `GET /api/bookings?date=YYYY-MM-DD`.
- New bookings POST to `POST /api/bookings`; the server injects the authenticated user's email server-side (see below) — the client never sends it.

## Alignment with the other leads

- **Endpoints match Backend & API Lead's spec**: `GET /api/resources`, `GET /api/bookings`, `POST /api/bookings`.
- **Overlap conflicts**: the UI surfaces whatever 409 error the backend returns from the Database Lead's overlap query (`start_time < new_end AND end_time > new_start`) directly in the modal.
- **Auth**: relies on Keycloak Lead's middleware to verify the bearer token and expose the email claim server-side — the frontend only ever attaches the token, never asserts identity itself.

## Local dev (before DevOps' docker-compose is wired up)

```bash
cd backend
npm install
# requires a running MySQL with database/schema.sql applied,
# and a running Keycloak realm matching keycloak-config.json
npm start
```

Then open http://localhost:3000.

## Config to align with DevOps

- `keycloakConfig` in `frontend/app.js` currently points at `http://localhost:8080/`
  — update to whatever hostname the Keycloak container is reachable at from the browser.
- `backend/keycloak-config.json` `auth-server-url` uses the internal Docker
  service name (`http://keycloak:8080/`) for server-to-server token validation.
- `backend/db.js` expects `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`
  from the root `.env` DevOps manages.
